

export default function Header() {
    return (
        <>
            <header id="header" className="header header-box-shadow-on-scroll header-abs-top header-bg-transparent header-white-nav-links-lg header-show-hide"
                data-hs-header-options='{
            "fixMoment": 1000,
            "fixEffect": "slide"
          }'>
                {/* Search */}
                <div id="searchPushTop" className="search-push-top">
                    <div className="container position-relative">
                        <div className="search-push-top-content pt-3">
                            {/* Close Button */}
                            <div className="search-push-top-close-btn">
                                <div className="hs-unfold">
                                    <a className="js-hs-unfold-invoker btn btn-icon btn-xs btn-soft-secondary mt-2 mr-2" href="javascript:;"
                                        data-hs-unfold-options='{
                  "target": "#searchPushTop",
                  "type": "jquery-slide",
                  "contentSelector": ".search-push-top"
                 }'>
                                        <svg width="10" height="10" viewBox="0 0 18 18" xmlns="http://www.w3.org/2000/svg">
                                            <path fill="currentColor" d="M11.5,9.5l5-5c0.2-0.2,0.2-0.6-0.1-0.9l-1-1c-0.3-0.3-0.7-0.3-0.9-0.1l-5,5l-5-5C4.3,2.3,3.9,2.4,3.6,2.6l-1,1 C2.4,3.9,2.3,4.3,2.5,4.5l5,5l-5,5c-0.2,0.2-0.2,0.6,0.1,0.9l1,1c0.3,0.3,0.7,0.3,0.9,0.1l5-5l5,5c0.2,0.2,0.6,0.2,0.9-0.1l1-1 c0.3-0.3,0.3-0.7,0.1-0.9L11.5,9.5z" />
                                        </svg>
                                    </a>
                                </div>
                            </div>
                            {/* End Close Button */}

                            {/* Input */}
                            <form className="input-group">
                                <input type="search" className="form-control" placeholder="Search Front" aria-label="Search Front" />
                                <div className="input-group-append">
                                    <button type="button" className="btn btn-primary">Search</button>
                                </div>
                            </form>
                            {/* End Input */}

                            {/* Content */}
                            <div className="row d-none d-md-flex mt-7">
                                <div className="col-sm-6">
                                    <span className="h5">Quick Links</span>

                                    <div className="row">
                                        {/* Nav Link */}
                                        <div className="col-6">
                                            <div className="nav nav-sm nav-x-0 flex-column">
                                                <a className="nav-link" href="#">
                                                    <i className="fas fa-angle-right mr-1"></i>
                                                    Search Results List
                                                </a>
                                                <a className="nav-link" href="#">
                                                    <i className="fas fa-angle-right mr-1"></i>
                                                    Search Results Grid
                                                </a>
                                                <a className="nav-link" href="#">
                                                    <i className="fas fa-angle-right mr-1"></i>
                                                    About
                                                </a>
                                                <a className="nav-link" href="#">
                                                    <i className="fas fa-angle-right mr-1"></i>
                                                    Services
                                                </a>
                                                <a className="nav-link" href="#">
                                                    <i className="fas fa-angle-right mr-1"></i>
                                                    Invoice
                                                </a>
                                            </div>
                                        </div>
                                        {/* End Nav Link */}

                                        {/* Nav Link */}
                                        <div className="col-6">
                                            <div className="nav nav-sm nav-x-0 flex-column">
                                                <a className="nav-link" href="#">
                                                    <i className="fas fa-angle-right mr-1"></i>
                                                    Profile
                                                </a>
                                                <a className="nav-link" href="#">
                                                    <i className="fas fa-angle-right mr-1"></i>
                                                    User Contacts
                                                </a>
                                                <a className="nav-link" href="#">
                                                    <i className="fas fa-angle-right mr-1"></i>
                                                    Reviews
                                                </a>
                                                <a className="nav-link" href="#">
                                                    <i className="fas fa-angle-right mr-1"></i>
                                                    Settings
                                                </a>
                                            </div>
                                        </div>
                                        {/* End Nav Link */}
                                    </div>
                                </div>

                                <div className="col-sm-6">
                                    {/* Banner */}
                                    <div className="rounded search-push-top-banner">
                                        <div className="d-flex align-items-center">
                                            {/* <div className="search-push-top-banner-container">
                    <img className="img-fluid search-push-top-banner-img" src="../../assets/img/mockups/img3.png" alt="Image Description">
                    <img className="img-fluid search-push-top-banner-img" src="../../assets/img/mockups/img2.png" alt="Image Description">
                  </div> */}

                                            <div>
                                                <div className="mb-4">
                                                    <span className="h5">Featured Item</span>
                                                    <p>Create astonishing web sites and pages.</p>
                                                </div>
                                                <a className="btn btn-xs btn-soft-success transition-3d-hover" href="javascript:;">Apply Now <i className="fas fa-angle-right fa-sm ml-1"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                    {/* End Banner */}
                                </div>
                            </div>
                            {/* End Content */}
                        </div>
                    </div>
                </div>
                {/* End Search */}

                <div className="header-section">
                    <div id="logoAndNav" className="container">
                        {/* Nav */}
                        <nav className="js-mega-menu navbar navbar-expand-lg">

                            Blogs Center
                            {/* Logo */}
                            {/* <a className="navbar-brand navbar-brand-default" href="../landings/index.html" aria-label="Front">
            <img src="../../assets/svg/logos/logo-white.svg" alt="Logo">
          </a> */}
                            {/* End Logo */}

                            {/* Logo */}
                            {/* <a className="navbar-brand navbar-brand-on-scroll" href="../landings/index.html" aria-label="Front">
            <img src="../../assets/svg/logos/logo.svg" alt="Logo">
          </a> */}
                            {/* End Logo */}

                            {/* Responsive Toggle Button */}
                            <button type="button" className="navbar-toggler btn btn-icon btn-sm rounded-circle"
                                aria-label="Toggle navigation"
                                aria-expanded="false"
                                aria-controls="navBar"
                                data-toggle="collapse"
                                data-target="#navBar">
                                <span className="navbar-toggler-default">
                                    <svg width="14" height="14" viewBox="0 0 18 18" xmlns="http://www.w3.org/2000/svg">
                                        <path fill="currentColor" d="M17.4,6.2H0.6C0.3,6.2,0,5.9,0,5.5V4.1c0-0.4,0.3-0.7,0.6-0.7h16.9c0.3,0,0.6,0.3,0.6,0.7v1.4C18,5.9,17.7,6.2,17.4,6.2z M17.4,14.1H0.6c-0.3,0-0.6-0.3-0.6-0.7V12c0-0.4,0.3-0.7,0.6-0.7h16.9c0.3,0,0.6,0.3,0.6,0.7v1.4C18,13.7,17.7,14.1,17.4,14.1z" />
                                    </svg>
                                </span>
                                <span className="navbar-toggler-toggled">
                                    <svg width="14" height="14" viewBox="0 0 18 18" xmlns="http://www.w3.org/2000/svg">
                                        <path fill="currentColor" d="M11.5,9.5l5-5c0.2-0.2,0.2-0.6-0.1-0.9l-1-1c-0.3-0.3-0.7-0.3-0.9-0.1l-5,5l-5-5C4.3,2.3,3.9,2.4,3.6,2.6l-1,1 C2.4,3.9,2.3,4.3,2.5,4.5l5,5l-5,5c-0.2,0.2-0.2,0.6,0.1,0.9l1,1c0.3,0.3,0.7,0.3,0.9,0.1l5-5l5,5c0.2,0.2,0.6,0.2,0.9-0.1l1-1 c0.3-0.3,0.3-0.7,0.1-0.9L11.5,9.5z" />
                                    </svg>
                                </span>
                            </button>
                            {/* End Responsive Toggle Button */}

                            {/* Navigation */}
                            <div id="navBar" className="collapse navbar-collapse">
                                <div className="navbar-body header-abs-top-inner">
                                    <ul className="navbar-nav">
                                        {/* Home */}
                                        <li className="hs-has-mega-menu navbar-nav-item">
                                            <a id="homeMegaMenu" className="hs-mega-menu-invoker nav-link nav-link-toggle" href="javascript:;" aria-haspopup="true" aria-expanded="false">Landings</a>
                                        </li>
                                        {/* End Home */}

                                        {/* Pages */}
                                        <li className="hs-has-sub-menu navbar-nav-item">
                                            <a id="pagesMegaMenu" className="hs-mega-menu-invoker nav-link nav-link-toggle" href="javascript:;" aria-haspopup="true" aria-expanded="false" aria-labelledby="pagesSubMenu">Pages</a>
                                        </li>
                                        {/* End Pages */}

                                        {/* Blog */}
                                        <li className="hs-has-sub-menu navbar-nav-item">
                                            <a id="blogMegaMenu" className="hs-mega-menu-invoker nav-link nav-link-toggle" href="javascript:;" aria-haspopup="true" aria-expanded="false" aria-labelledby="blogSubMenu">Blog</a>
                                        </li>
                                        {/* End Blog */}

                                        {/* Shop */}
                                        <li className="hs-has-mega-menu navbar-nav-item"
                                            data-hs-mega-menu-item-options='{
                      "desktop": {
                        "position": "right",
                        "maxWidth": "440px"
                      }
                    }'>
                                            <a id="shopMegaMenu" className="hs-mega-menu-invoker nav-link nav-link-toggle" href="javascript:;" aria-haspopup="true" aria-expanded="false">Shop</a>

                                        </li>
                                        {/* End Shop */}

                                        {/* Demos */}
                                        <li className="hs-has-mega-menu navbar-nav-item"
                                            data-hs-mega-menu-item-options='{
                      "desktop": {
                        "position": "right",
                        "maxWidth": "900px"
                      }
                    }'>
                                            <a id="demosMegaMenu" className="hs-mega-menu-invoker nav-link nav-link-toggle" href="javascript:;" aria-haspopup="true" aria-expanded="false">Demos</a>

                                        </li>
                                        {/* End Demos */}

                                        {/* Docs */}
                                        <li className="hs-has-mega-menu navbar-nav-item"
                                            data-hs-mega-menu-item-options='{
                                                "desktop": {
                                                    "position": "right",
                                                    "maxWidth": "260px"
                                                }
                                                }'>
                                                        <a id="docsMegaMenu" className="hs-mega-menu-invoker nav-link nav-link-toggle" href="javascript:;" aria-haspopup="true" aria-expanded="false">Docs</a>
                                        </li>
                                        {/* End Docs */}

                                        {/* Button */}
                                        <li className="navbar-nav-last-item">
                                            <a className="btn btn-sm btn-primary transition-3d-hover" href="https://themes.getbootstrap.com/product/front-multipurpose-responsive-template/" target="_blank">
                                                Buy Now
                                            </a>
                                        </li>
                                        {/* End Button */}
                                    </ul>
                                </div>
                            </div>
                            {/* End Navigation */}
                        </nav>
                        {/* End Nav */}
                    </div>
                </div>
            </header>
        </>
    )
}