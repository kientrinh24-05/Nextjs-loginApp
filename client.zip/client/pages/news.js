import React from 'react'

function news() {
  return (
    <div>
    {/* Blogs Section */}
    <div class="container space-2 space-lg-3">
      <div class="row justify-content-lg-between">
        <div class="col-lg-8">
          {/* Blog */}
          <article class="row mb-7">
            <div class="col-md-5">
              <img class="card-img" src="https://images.unsplash.com/photo-1499750310107-5fef28a66643?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80" alt="Image Description"/>
            </div>
            <div class="col-md-7">
              <div class="card-body d-flex flex-column h-100 px-0">
                <span class="d-block mb-2">
                  <a class="font-weight-bold" href="#">Announcements</a>
                </span>
                <h3><a class="text-inherit" href="single-article.html">Announcing a free plan for small teams</a></h3>
                <p>At Wake, our mission has always been focused on bringing openness.</p>
                <div class="media align-items-center mt-auto">
                  <a class="avatar avatar-sm avatar-circle mr-3" href="blog-profile.html">
                    <img class="avatar-img" src="https://media.istockphoto.com/photos/young-book-author-picture-id1336524166?s=612x612" alt="Image Description"/>
                  </a>
                  <div class="media-body">
                    <span class="text-dark">
                      <a class="d-inline-block text-inherit font-weight-bold" href="blog-profile.html">Hanna Wolfe</a>
                    </span>
                    <small class="d-block">Feb 4, 2020</small>
                  </div>
                </div>
              </div>
            </div>
          </article>
          {/* End Blog */}

          {/* Sticky Block End Point */}
          <div id="stickyBlockEndPoint"></div>
        </div>

        <div class="col-lg-3">
          <div class="mb-7">
            <div class="mb-3">
              <h3>Productivity</h3>
            </div>

            {/* Blog */}
            <article class="mb-3">
              <a class="card card-frame p-3" href="#">
                <div class="media align-items-center">
                  <div class="media-body mr-2">
                    <h4 class="h6 mb-0">Here's how to dodge distractions</h4>
                    <span class="d-block font-size-1 text-body">Feb 08, 2020</span>
                  </div>
                  <i class="fas fa-angle-right"></i>
                </div>
              </a>
            </article>
            {/* End Blog */}

          </div>

          {/* Sticky Block Start Point */}
          <div id="stickyBlockStartPoint"></div>
        </div>
      </div>
    </div>
    {/* End Blogs Section */}

    </div>
  )
}

export default news