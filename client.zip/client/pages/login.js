import React, { useEffect } from 'react'
import { Row, Col } from 'antd';
// import { useHistory } from 'react-router-dom';
import FormLogin from '../components/Login/index';

export default function Login() {
    
    // const history = useHistory();

    // useEffect(() => {
    //     if (token && login && userInfo) {
    //         history.push('/admin/dashboard')
    //     }
    // }, [token]);

    // useEffect(() => {
    //     if (userInfo) {
    //         // dispatch(getAcount(user.id));
    //     }
    // }, []);

    return (
        <div className="wraper">
            <div className="container">
                <Row>
                    <Col span={12}>
                        <div className="bg-image">
                        </div>
                    </Col>
                    <Col span={4}></Col>
                    <Col span={8}>
                        <FormLogin/>
                    </Col>
                </Row>
            </div>
           {/* <Particles /> */}
        </div>
    )
}
